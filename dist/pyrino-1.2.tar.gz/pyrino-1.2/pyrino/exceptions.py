class USERNAME_NOT_EXIST(Exception):
    pass

class SERVER_ERROR(Exception):
    pass

class NOT_REGISTERED(Exception):
    pass

class INVALID_INPUT(Exception):
    pass