from ._rubino import Client

__version__: str = '1.2'
__author__: str = 'Shayan Heidari'
__copyright__: str = 'GNU Lesser General Public License v3 (LGPLv3)'